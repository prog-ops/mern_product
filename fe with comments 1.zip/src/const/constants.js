export const API_URL1 = 'http://localhost:3001/api/productlist'
export const API_URL = 'http://localhost:3001/produk'
