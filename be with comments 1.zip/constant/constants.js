const allowedType = ['.png', '.jpg', '.jpeg']

export { allowedType }
